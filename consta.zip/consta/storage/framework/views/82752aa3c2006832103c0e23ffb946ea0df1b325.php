<?php $__env->startSection('title'); ?>
<?php echo e("Total Score"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="w3-container">
  <h2>Score of all Students</h2>
  
  
  

    
                <table class="w3-table-all w3-card-4" id="studentMarksdetails">
                    <thead>
                        <tr>
                            
                            <tr>
                                <th>Photo</th>
                                <th>Student Name</th>
                                <th>Roll No</th>
                                
                                <th>Class</th>
                                <th>Total Score</th>
                            </tr>
                        </tr>
                    </thead>
                    <tbody>
                            <?php if(isset($totalScore)): ?>
                            <?php $__currentLoopData = $totalScore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1=>$ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><a href="<?php echo e(asset('images/'.$ts->photo)); ?>">
                                        <img alt="photo link" src="<?php echo e(asset('images/'.$ts->photo)); ?>" width=100
                                            height="100">
                                    </a></td>
                                <td><?php echo e($ts->student_name); ?></td>
                                <td><?php echo e($ts->roll_no); ?></td>

                                
                                <td><?php echo e($ts->class_name); ?></td>
                                <td><?php echo e($ts->total); ?></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                </table>
  
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\consta\resources\views/students/student-total-score.blade.php ENDPATH**/ ?>