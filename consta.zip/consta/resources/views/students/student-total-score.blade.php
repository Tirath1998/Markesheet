@extends('layouts.master')
@section('title')
{{"Total Score"}}
@endsection
@section('content')

<div class="w3-container">
  <h2>Score of all Students</h2>
  
  
  

    
                <table class="w3-table-all w3-card-4" id="studentMarksdetails">
                    <thead>
                        <tr>
                            
                            <tr>
                                <th>Photo</th>
                                <th>Student Name</th>
                                <th>Roll No</th>
                                
                                <th>Class</th>
                                <th>Total Score</th>
                            </tr>
                        </tr>
                    </thead>
                    <tbody>
                            @isset($totalScore)
                            @foreach ($totalScore as $key1=>$ts)

                            <tr>
                                <td><a href="{{asset('images/'.$ts->photo)}}">
                                        <img alt="photo link" src="{{asset('images/'.$ts->photo)}}" width=100
                                            height="100">
                                    </a></td>
                                <td>{{$ts->student_name}}</td>
                                <td>{{$ts->roll_no}}</td>

                                
                                <td>{{$ts->class_name}}</td>
                                <td>{{$ts->total}}</td>
                            </tr>

                            @endforeach
                            @endisset
                        </tbody>
                </table>
  
</div>


@endsection